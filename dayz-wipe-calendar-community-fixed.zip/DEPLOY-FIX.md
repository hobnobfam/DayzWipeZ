# Render deployment fix

The Node server serves `public/index.html`, so the frontend must be committed at:
`public/index.html`.

The Render Blueprint also provisions PostgreSQL and supplies:
- DATABASE_URL
- JWT_SECRET

After extracting this project, commit the files to the GitHub repository and redeploy/sync the Render Blueprint.
